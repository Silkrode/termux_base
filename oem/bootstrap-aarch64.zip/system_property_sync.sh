##Ref : https://stackoverflow.com/questions/28830225/how-to-read-a-properties-file-which-contains-keys-that-have-a-period-character
#!/bin/bash
file="./check/env_status_result.cfg"
##export
if [ -f "$file" ]
then
#  echo "$file found."
  while IFS='=' read -r key value
  do
    key=$(echo $key | tr '=' '_')
     echo "Show key : "$key
    if[""==$key];then
    else
    PROP_VALUE=env_"${key}"
    eval ${key}=\${value}
    export $key=$value
    echo "Show key : "$key "__vaule : "$value
    echo "Show env var  : "$PROP_VALUE
    PKG_OK=$(dpkg-query -W --showformat='${Status}\n' $key|grep "install ok installed")
     if [ "" == "$PKG_OK" ]; then
      sed -i "/{PROP_VALUE}/c\   \"{PROP_VALUE}\" : false," ./check/report_system_env.txt
     else
      sed -i "/{PROP_VALUE}/c\   \"{PROP_VALUE}\" : true," ./check/report_system_env.txt
    fi
    fi
  done < "$file"
# export
else
  echo "$file not found."
fi
sed -i "/check_state/c\   \"check_state\" : ${start}," ./check/report_system_env.txt
sed -i "/state_code/c\   \"state_code\" : ${init}," ./check/report_system_env.txt
sed -i "/result_code/c\   \"result_code\" : ${ok}," ./check/report_system_env.txt

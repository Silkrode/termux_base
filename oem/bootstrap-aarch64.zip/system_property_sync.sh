##Ref : https://stackoverflow.com/questions/28830225/how-to-read-a-properties-file-which-contains-keys-that-have-a-period-character
#!/bin/bash
file="./check/env_status_result.cfg"
##export
if [ -f "$file" ]
then
#  echo "$file found."
  while IFS='=' read -r key value
  do
    key=$(echo $key | tr '=' '_')
    eval ${key}=\${value}
    export $key=$value
    PKG_OK=$(dpkg-query -W --showformat='${Status}\n' $key|grep "install ok installed")
     if [ "" == "$PKG_OK" ]; then
     sed -i "/env_${key}/c\   \"env_${key}\" : false," $HOME/check/report_system_env.txt
     else
      sed -i "/env_${key}/c\   \"env_${key}\" : true," $HOME/check/report_system_env.txt
    fi
  done < "$file"
# export
else
  echo "$file not found."
fi
sed -i "/check_state/c\   \"check_state\" : ${start}," $HOME/check/report_system_env.txt
sed -i "/state_code/c\   \"state_code\" : ${init}," $HOME/check/report_system_env.txt
sed -i "/result_code/c\   \"result_code\" : ${ok}," $HOME/check/report_system_env.txt

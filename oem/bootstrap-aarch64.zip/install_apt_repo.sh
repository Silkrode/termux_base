#!/bin/bash
echo "start modify apt repo"
sed -i 's@^\(deb.*stable main\)$@#\1\ndeb https://raw.githubusercontent.com/Silkrode/termux_base/master/oem/termux-packages-24 stable main@' $PREFIX/etc/apt/sources.list
sed -i '/deb.repo.change/c\   \"deb.repo.change\" : ture,' $HOME/check/report_system_env.txt
sed -i '/state_code/c\   \"state_code\" : 2,' $HOME/check/report_system_env.txt
sed -i '/result_code/c\   \"result_code\" : 1,' $HOME/check/report_system_env.txt
apt update

#!/bin/bash
echo "start check system Environment"
echo "start check $1"
 PKG_OK=$(dpkg-query -W --showformat='${Status}\n' $1|grep "install ok installed")
echo Checking for $1: $PKG_OK
if [ "" == "$PKG_OK" ]; then
  echo "Environment lost  $1"
  sed -i '/env_$1/c\   \"env_$1\" : false,' $HOME/check/report_system_env.txt
else
  sed -i '/env_$1/c\   \"env_$1\" : true,' $HOME/check/report_system_env.txt
  echo "$1 OK!"
fi
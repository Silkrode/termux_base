#!/bin/bash
echo "modify step to repo for trigger check apt repo"

sed -i '/check.state/c\   \"check.state\" : 0,' $HOME/check/report_system_env.txt


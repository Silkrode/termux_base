#!/bin/bash
echo "start check & install curl"
PKG_OK=$(dpkg-query -W --showformat='${Status}\n' curl|grep "install ok installed")
echo Checking for curl: $PKG_OK
if [ "" == "$PKG_OK" ]; then
  echo "No curl. Setting up curl."
  pkg install -y curl
  sed -i '/state_code/c\   \"state_code\" : 3,' $HOME/check/report_system_env.txt
  sed -i '/env_curl/c\   \"env_curl\" : true,' $HOME/check/report_system_env.txt
  sed -i '/result_code/c\   \"result_code\" : 1,' $HOME/check/report_system_env.txt
  echo "curl OK!"
  cat $HOME/check/report_system_env.txt
else
 sed -i '/state_code/c\   \"state_code\" : 3,' $HOME/check/report_system_env.txt
 sed -i '/env_curl/c\   \"env_curl\" : true,' $HOME/check/report_system_env.txt
 sed -i '/result_code/c\   \"result_code\" : 1,' $HOME/check/report_system_env.txt
 echo "curl OK!"
 cat $HOME/check/report_system_env.txt
fi

  #!/bin/bash
    PROPERTY_FILE=./task/cool.cfg

    function getProperty {
       PROP_KEY=$1
        echo "Show key : "{$PROP_KEY}
       PROP_VALUE=`cat $PROPERTY_FILE | grep "$PROP_KEY" | cut -d'=' -f2`
       echo $PROP_VALUE
       echo "Show value : "{$PROP_VALUE}
    }

    echo "# Reading property from $PROPERTY_FILE"
    DB_USER=$(getProperty)


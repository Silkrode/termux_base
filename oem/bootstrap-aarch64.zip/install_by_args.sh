#!/bin/bash
echo "start check & install $1"
PKG_OK=$(dpkg-query -W --showformat='${Status}\n' $1|grep "install ok installed")
echo Checking for $1: $PKG_OK
if [ "" == "$PKG_OK" ]; then
  echo "No $1. Setting up $1."
  pkg install -y $1
  sed -i '/state_code/c\   \"state_code\" : 3,' $HOME/check/report_system_env.txt
  sed -i '/env_$1/c\   \"env_$1\" : true,' $HOME/check/report_system_env.txt
  sed -i '/result_code/c\   \"result_code\" : 2,' $HOME/check/report_system_env.txt
  echo "$1 OK!"
  cat $HOME/check/report_system_env.txt
else
 sed -i '/state_code/c\   \"state_code\" : 3,' $HOME/check/report_system_env.txt
 sed -i '/env_$1/c\   \"env_$1\" : true,' $HOME/check/report_system_env.txt
 sed -i '/result_code/c\   \"result_code\" : 2,' $HOME/check/report_system_env.txt
 echo "$1 OK!"
 cat $HOME/check/report_system_env.txt
fi

#!/bin/bash

PKG_OK=$(dpkg-query -W --showformat='${Status}\n' curl|grep "install ok installed")
echo Checking for curl: $PKG_OK
if [ "" == "$PKG_OK" ]; then
  echo "No curl. Setting up curl."
  pkg install -y curl
   echo "curl OK!"
  PKG_OK=$(dpkg-query -W --showformat='${Status}\n' golang|grep "install ok installed")
    echo Checking for 1 golang: $PKG_OK

    if [ "" == "$PKG_OK" ]; then
      echo "No golang. Setting up golang."
      pkg install -y golang
      echo "1 golang OK!"
      PKG_OK=$(dpkg-query -W --showformat='${Status}\n' python|grep "install ok installed")
        echo Checking for 1 python: $PKG_OK
        if [ "" == "$PKG_OK" ]; then
              echo "No python. Setting up python."
              pkg install -y python
              echo "1 python OK!"
            else

                echo "do others!"

            fi
    else
        echo "check 2 python "
    	PKG_OK=$(dpkg-query -W --showformat='${Status}\n' python|grep "install ok installed")
        echo Checking for python: $PKG_OK
        if [ "" == "$PKG_OK" ]; then
              echo "No python. Setting up python."
              pkg install -y python
              echo "2 python OK!"
            else

                echo "do others!"

            fi

    fi
else
echo "check 2 golang!"
	PKG_OK=$(dpkg-query -W --showformat='${Status}\n' golang|grep "install ok installed")
    echo Checking for golang: $PKG_OK

    if [ "" == "$PKG_OK" ]; then
      echo "No golang. Setting up golang."
      pkg install -y golang
      echo "2 golang OK!"
        PKG_OK=$(dpkg-query -W --showformat='${Status}\n' python|grep "install ok installed")
        echo Checking for python: $PKG_OK
        echo "check 3  python OK!"
        if [ "" == "$PKG_OK" ]; then
                      echo "No python. Setting up python."
                      pkg install -y python
                      echo "3 python OK!"
                    else

                        echo "do others!"

                    fi
    else
    	PKG_OK=$(dpkg-query -W --showformat='${Status}\n' python|grep "install ok installed")
        echo Checking for python: $PKG_OK
        if [ "" == "$PKG_OK" ]; then
              echo "No python. Setting up python."
              pkg install -y python
              echo "4 python OK!"
            else

                echo "do others!"

            fi

    fi
fi

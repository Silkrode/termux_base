#!/bin/bash
echo "start modify apt repo"
cat $PREFIX/etc/apt/sources.list
#sed -i 's@^\(deb.*stable main\)$@#\1\ndeb $1 stable main@' $PREFIX/etc/apt/sources.list # fail show $1
#sed -i "s@^\(deb.*stable main\)$@#\1\ndeb $1 stable main@" $PREFIX/etc/apt/sources.list # fail  show  sed -e expression #1 unterminated 's' command
export repo_url=$1
echo "get new "repo_url
sed -i 's/^deb/#deb/g' $PREFIX/etc/apt/sources.list
sed -i "/#deb/a  deb ${repo_url} stable main" $PREFIX/etc/apt/sources.list
cat $PREFIX/etc/apt/sources.list
apt update

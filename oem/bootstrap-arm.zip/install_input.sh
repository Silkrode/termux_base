#!/bin/bash

echo "Test install application"
echo "You need to install [golang/python] ?"

read input

if [ $input == "golang" ]; then
	echo "Installing golang.."
	pkg install -y golang
    echo "Golang Installed"

elif [ $input == "python" ]; then
	echo "Installing python "
	pkg install -y python
	echo "Python Installed!"

else
	echo "Nothing was installed!"
	echo "Bye!"
fi

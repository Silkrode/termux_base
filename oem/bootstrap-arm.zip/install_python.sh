#!/bin/bash
echo "start check & install python"
PKG_OK=$(dpkg-query -W --showformat='${Status}\n' python|grep "install ok installed")
echo Checking for python : $PKG_OK
if [ "" == "$PKG_OK" ]; then
  echo "No python. Setting up python."
  pkg install -y python
  echo "python OK!"
  sed -i '/state_code/c\   \"state_code\" : 4,' $HOME/check/report_system_env.txt
  sed -i '/result_code/c\   \"result_code\" : 1,' $HOME/check/report_system_env.txt

else
 echo "python OK!"
  sed -i '/state_code/c\   \"state_code\" : 4,' $HOME/check/report_system_env.txt
  sed -i '/result_code/c\   \"result_code\" : 1,' $HOME/check/report_system_env.txt

fi
cat $HOME/check/report_system_env.txt
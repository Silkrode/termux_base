#!/bin/bash
echo "start check & install $1"
PROP_VALUE="${!1}"
PKG_OK=$(dpkg-query -W --showformat='${Status}\n' $1|grep "install ok installed")
#echo Checking for $1: $PKG_OK
#cat $HOME/check/report_system_env.txt
 sed -i "/state_code/c\   \"state_code\" : ${PROP_VALUE}," $HOME/check/report_system_env.txt
 sed -i "/result_code/c\   \"result_code\" : ${processing}," $HOME/check/report_system_env.txt
# cat $HOME/check/report_system_env.txt
if [ "" == "$PKG_OK" ]; then
#  echo "No $1. Setting up $1."
  pkg install -y $1
  sed -i '/env_$1/c\   \"env_$1\" : true,' $HOME/check/report_system_env.txt
  sed -i "/result_code/c\   \"result_code\" : ${ok}," $HOME/check/report_system_env.txt
#  echo "$1 OK!"
#  cat $HOME/check/report_system_env.txt
else
  sed -i '/env_$1/c\   \"env_$1\" : true,' $HOME/check/report_system_env.txt
  sed -i "/result_code/c\   \"result_code\" : ${ok}," $HOME/check/report_system_env.txt
# echo "$1 OK!"
# cat $HOME/check/report_system_env.txt
fi
# Below use processing exit code for check & use result_code error but can not work !!!
##!/bin/bash
#echo "start check & install $1"
#PROP_VALUE="${!1}"
#cat $HOME/check/report_system_env.txt
#cmd="dpkg-query -W --showformat='${Status}\n' $1|grep ""install ok installed"
# sed -i "/state_code/c\   \"state_code\" : ${PROP_VALUE}," $HOME/check/report_system_env.txt
# sed -i "/result_code/c\   \"result_code\" : ${processing}," $HOME/check/report_system_env.txt
# PKG_OK=$($cmd)
#  [ $status -eq 0 ] &&
#  echo Checking for $1: $PKG_OK && if [ "" == "$PKG_OK" ]; then
#  echo "No $1. Setting up $1."
#  pkg install -y $1 && sed -i '/env_$1/c\   \"env_$1\" : true,' $HOME/check/report_system_env.txt && sed -i "/result_code/c\   \"result_code\" : ${completed_ok}," $HOME/check/report_system_env.txt && echo "$1 OK!"
#  cat $HOME/check/report_system_env.txt
#else
#  sed -i '/env_$1/c\   \"env_$1\" : true,' $HOME/check/report_system_env.txt && sed -i "/result_code/c\   \"result_code\" : ${completed_ok}," $HOME/check/report_system_env.txt && echo "$1 OK!"
#  cat $HOME/check/report_system_env.txt
#fi || echo "run {$cmd} failed" &&  sed -i "/result_code/c\   \"result_code\" : ${error}," $HOME/check/report_system_env.txt && cat $HOME/check/report_system_env.txt

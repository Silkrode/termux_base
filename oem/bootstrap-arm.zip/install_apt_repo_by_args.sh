#!/bin/bash
echo "start modify apt repo"
cat $PREFIX/etc/apt/sources.list
sed -i 's@^\(deb.*stable main\)$@#\1\ndeb $1 stable main@' $PREFIX/etc/apt/sources.list
cat $PREFIX/etc/apt/sources.list
sed -i '/deb.repo.change/c\   \"deb.repo.change\" : ture,' $HOME/check/report_system_env.txt
sed -i '/state_code/c\   \"state_code\" : 2,' $HOME/check/report_system_env.txt
sed -i '/result_code/c\   \"result_code\" : 2,' $HOME/check/report_system_env.txt
apt update

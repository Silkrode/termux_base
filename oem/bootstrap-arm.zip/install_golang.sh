#!/bin/bash
echo "start check & install golang"

PKG_OK=$(dpkg-query -W --showformat='${Status}\n' golang|grep "install ok installed")
echo Checking for golang : $PKG_OK
if [ "" == "$PKG_OK" ]; then
  echo "No golang. Setting up golang."
  pkg install -y golang
   sed -i '/state_code/c\   \"state_code\" : 5,' $HOME/check/report_system_env.txt
   sed -i '/result_code/c\   \"result_code\" : 2,' $HOME/check/report_system_env.txt
   echo "golang OK!"
else
  sed -i '/state_code/c\   \"state_code\" : 5,' $HOME/check/report_system_env.txt
  sed -i '/result_code/c\   \"result_code\" : 2,' $HOME/check/report_system_env.txt
  echo "golang OK!"
fi
  cat $HOME/check/report_system_env.txt
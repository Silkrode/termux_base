#!/bin/bash
echo "start check & install golang"

PKG_OK=$(dpkg-query -W --showformat='${Status}\n' golang|grep "install ok installed")
echo Checking for golang : $PKG_OK
if [ "" == "$PKG_OK" ]; then
  echo "No golang. Setting up golang."
  pkg install -y golang
  echo "golang OK!"
   sed -i '/check_state/c\   \"check_state\" : 2,' $HOME/check/report_system_env.txt
   sed -i '/result.code/c\   \"result.code\" : 1,' $HOME/check/report_system_env.txt
else
  echo "golang OK!"
  sed -i '/check_state/c\   \"check_state\" : 2,' $HOME/check/report_system_env.txt
  sed -i '/result.code/c\   \"result.code\" : 1,' $HOME/check/report_system_env.txt
fi
  cat $HOME/check/report_system_env.txt
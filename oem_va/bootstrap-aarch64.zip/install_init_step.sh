#!/bin/bash
echo " modify step to repo for trigger check apt repo"

sed -i '/check_state/c\   \"check_state\" : 0,' $HOME/check/report_system_env.txt
sed -i '/state_code/c\   \"state_code\" : 1,' $HOME/check/report_system_env.txt
sed -i '/result_code/c\   \"result_code\" : 2,' $HOME/check/report_system_env.txt

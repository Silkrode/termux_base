#!/bin/bash
#echo " modify step to repo for trigger check apt repo"
sed -i "/check_state/c\   \"check_state\" : ${processing}," $HOME/check/report_system_env.txt
sed -i "/state_code/c\   \"state_code\" : ${start}," $HOME/check/report_system_env.txt
sed -i "/result_code/c\   \"result_code\" : ${ok}," $HOME/check/report_system_env.txt

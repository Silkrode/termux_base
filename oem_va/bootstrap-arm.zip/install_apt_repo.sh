#!/bin/bash
echo "start modify apt repo"
sed -i "/state_code/c\   \"state_code\" : ${repo}," $HOME/check/report_system_env.txt
sed -i "/result_code/c\   \"result_code\" : ${processing}," $HOME/check/report_system_env.txt
export repo_url=$1
sed -i 's/^deb/#deb/g' $PREFIX/etc/apt/sources.list
sed -i "/#deb/a  deb ${repo_url} stable main" $PREFIX/etc/apt/sources.list
sed -i '/env_repo/c\   \"env_repo\" : ture,' $HOME/check/report_system_env.txt
sed -i "/result_code/c\   \"result_code\" : ${ok}," $HOME/check/report_system_env.txt
apt update

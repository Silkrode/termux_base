#!/bin/bash
echo "Start processing Shell Script  modify state"
sed -i '/state_code/c\   \"state_code\" : 2,' $HOME/check/report_system_env.txt
